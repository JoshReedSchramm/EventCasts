## Welcome to your Rails Rumble 2009 Repository

To get started, you need to clone this repository
using your private URL above.

Please note that if you instead have generated / initialized
a git repository (e.g. via a rails template), you need to
do roughly the following steps:

    git remote add origin <your-repositry-url-above>
    git push --force origin master
  
If you have any other issues, please contact us using
http://support.railsrumble.com or by using the #railsrumble
IRC channel on Freenode.