class SearchResult
  attr_accessor :group, :user, :property_name, :query
end
